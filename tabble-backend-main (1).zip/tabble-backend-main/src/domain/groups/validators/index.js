'use strict';

const { GroupsValidator } = require('./groups-validator');

module.exports = {
    GroupsValidator
};
