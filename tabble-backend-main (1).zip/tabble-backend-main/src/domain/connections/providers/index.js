"use strict";

const { ConnectionsProvider } = require("./connections-provider");

module.exports = {
  ConnectionsProvider,
};
