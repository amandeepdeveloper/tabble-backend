'use strict';

const { ConnectionsValidator } = require('./connections-validator');

module.exports = {
    ConnectionsValidator
};
