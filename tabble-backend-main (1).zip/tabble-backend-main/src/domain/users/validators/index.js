'use strict';

const { UserValidator } = require('./user-validator');

module.exports = {
  UserValidator
};
