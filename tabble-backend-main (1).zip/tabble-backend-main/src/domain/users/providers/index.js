"use strict";

const { UserProvider } = require("./user-provider");

module.exports = {
  UserProvider,
};
