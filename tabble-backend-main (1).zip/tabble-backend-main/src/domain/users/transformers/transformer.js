'use strict';

class Transformer {

  constructor() {}
}

module.exports = {
  Transformer
};
