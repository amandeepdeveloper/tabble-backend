'use strict';

const { AuthValidator } = require('./auth-validator');

module.exports = {
  AuthValidator
};
