# README #

Express based REST API that facilitates Tabble.

## Getting Started

### Prerequisites
`Node v11.6.0`
`npm install`

### Installing
`git clone `

`npm install`

### Running
`npm start`

### Running the tests
`npm run test`

### Linting
`npm run lint`
