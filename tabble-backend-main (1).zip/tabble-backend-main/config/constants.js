'use strict';

const constants = {};

constants.DEFAULT_MONGO_PORT = 27017;
constants.DEFAULT_APP_PORT = 3004;

module.exports = constants;

